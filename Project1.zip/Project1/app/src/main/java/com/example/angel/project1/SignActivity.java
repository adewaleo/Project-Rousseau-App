package com.example.angel.project1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Spinner;

/**
 * Created by angel on 6/7/2016.
 */
public class SignActivity extends AppCompatActivity {
    private Spinner spinnerCardNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);
        spinnerCardNumber = (Spinner)findViewById(R.id.spinner);
    }

    public void BackSign(View v) {
        Intent i = new Intent(SignActivity.this, LoginActivity.class);
        startActivity(i);

    }


    public void Nextmenu(View v) {
        String cardNumber = spinnerCardNumber.getSelectedItem().toString();
        if (cardNumber.equals("Mentee") ) {
            Intent i = new Intent(SignActivity.this, SignMenteeActivity.class);
            startActivity(i);
        }
        else if(cardNumber.equals("Mentor")||cardNumber.equals("Staff")||cardNumber.equals("Chapter leader")){
            Intent i = new Intent(SignActivity.this, SignupActivity.class);
            startActivity(i);
        }

    }

}
