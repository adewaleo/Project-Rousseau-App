package com.example.angel.project1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Switch;

/**
 * Created by angel on 6/21/2016.
 */
public class SignupActivity extends AppCompatActivity {
    private Switch switchstate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        switchstate = (Switch)findViewById(R.id.switch1);
    }
    public void BackSignup(View v) {
        Intent i = new Intent(SignupActivity.this, SignActivity.class);
        startActivity(i);

    }

    public void NextSign(View v) {
        if (switchstate.isChecked()){
            Intent i = new Intent(SignupActivity.this, CarInsure.class);
            startActivity(i);
        }
    }
}
