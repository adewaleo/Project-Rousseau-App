package com.example.angel.project1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by angel on 6/14/2016.
 */
public class SignMenteeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_signmentee);

    }
    public void BackSignmentee(View v) {
        Intent i = new Intent(SignMenteeActivity.this, SignActivity.class);
        startActivity(i);

    }
}